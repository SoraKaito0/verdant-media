Verdant 15.4.12 - Run Tools > Verdant Board > V15.4.12 > Apply Supporters + Clock + Version Fix in a backed-up Unity project.
Unity/UdonSharp testing is still required.
