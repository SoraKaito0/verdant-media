# Verdant World System 15.4.7

V15.4.7 fixes the V15.4.6 Editor/runtime type mismatch.

## Main repair

The clock controller no longer reuses the old `VerdantVpmSharedClock` class at all.

The package now ships:

- `VerdantClockController1547.cs`
- a brand-new class: `VerdantClockController1547`
- a brand-new Unity GUID for that runtime script
- an installer that references only the new class

That prevents Unity/UdonSharp from resolving the V15.4.7 installer against a stale cached definition of the older clock controller.

V15.4.7 also retains:
- the proper Runtime/Editor/UdonSharp assembly structure
- VerdantRoleAuthority
- the independent Verdant.Menu diagnostics assembly
- supporter scrolling repair
- 12/24-hour toggle/dropdown sync
- iPad/Main Board version-label repair

After updating through VCC:
1. Reopen Unity and wait for compilation.
2. Check **Tools > Verdant Board > Diagnostics > Package Status**.
3. Run **Tools > Verdant Board > V15.4.7 > Apply Supporters + Clock + Version Fix**.
