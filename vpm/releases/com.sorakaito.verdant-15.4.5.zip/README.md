# Verdant World System 15.4.5

V15.4.5 replaces the generic UI-state guards with direct ownership of the affected Verdant UI.

## Fixes

- Detects and links both Main Board and iPad clock labels using the actual VerdantBoard / VerdantTablet scene components when available.
- Supports 12/24-hour settings implemented as Toggles, TMP_Dropdowns, or legacy Dropdowns.
- Detaches legacy clock/time text references from older scene scripts so they cannot overwrite the shared clock output.
- Updates all existing Verdant version labels, including old iPad Version 14.5 text, to V15.4.5.
- Creates a small Main Board version label only when no version label exists there.
- Replaces the every-frame supporter scroll fight with a delayed two-frame restore after a layout reset, plus user-interaction grace/cooldown to reduce stutter.
- Retains the proper Runtime/Editor asmdefs, UdonSharp assembly registration and VerdantRoleAuthority supplied in 15.4.4.

After updating through VCC:
Tools > Verdant Board > V15.4.5 > Apply Supporters + Clock + Version Fix
