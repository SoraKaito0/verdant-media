# Verdant World System 15.4.2

## Fixes
- Protects every vertical ScrollRect inside the Supporters/Support board against programmatic snap-to-top refreshes.
- Detects actual time-looking text on both Main Board and iPad, not only specially named Clock objects.
- Uses one shared local clock state for both surfaces.
- Wires detected 12-hour and 24-hour buttons to the shared clock.
- Runs the shared clock and scroll guard late so older local scripts cannot easily overwrite them afterward.
- Restores or creates a small V15.4.2 label on the Main Board.

After updating through VCC:
Tools > Verdant Board > V15.4.2 > Apply Supporters + Clock + Version Fix
