# Verdant World System 15.4.4

V15.4.4 repairs the VCC package structure itself.

## Packaging fixes

- Adds `Runtime/Verdant.Runtime.asmdef`.
- Adds the matching UdonSharp assembly registration asset so package UdonSharp behaviours are compiled by UdonSharp.
- Adds `Editor/Verdant.Editor.asmdef` referencing Verdant.Runtime and the required VRChat/UdonSharp/UI assemblies.
- Restores `VerdantRoleAuthority` inside the Runtime package with its original Unity GUID so existing VRCLinking scene/bridge references survive migration.
- Keeps the collision-proof VPM clock, supporter-scroll and V15.4.4 scene installer.

After updating in VCC and reopening Unity, verify:

Tools > Verdant Board > Diagnostics > Show VPM Status

Then run:

Tools > Verdant Board > V15.4.4 > Apply Supporters + Clock + Version Fix
