# Verdant World System 15.4.3

This hotfix makes the VCC package collision-proof against older extracted Verdant scripts.

After updating in VCC and reopening Unity, you should see:

Tools > Verdant Board > V15.4.3 > Apply Supporters + Clock + Version Fix

and:

Tools > Verdant Board > Diagnostics > Show VPM Status

The package uses unique VPM class names, so legacy Assets/VerdantBoard scripts can remain present without creating duplicate class definitions.

The V15.4.3 installer:
- protects Supporters-page vertical ScrollRects from snap-to-top resets
- links Main Board and iPad time displays to one local clock state
- links detected 12/24-hour toggles
- restores/creates the Main Board version label
- creates a scene backup first
