# Verdant World System 15.4.6

V15.4.6 is a menu-recovery and runtime-safety hotfix.

## What changed

- Removed generic `List<T>` usage from UdonSharp runtime code.
- Removed `Input.mouseScrollDelta` usage from UdonSharp runtime code.
- Dropdown option labels are analyzed only by the Editor installer; runtime receives simple integer index arrays.
- Added `Verdant.Menu.asmdef`, a tiny Editor-only assembly with no dependency on Verdant Runtime.
- Added **Tools > Verdant Board > Diagnostics > Package Status** from that independent assembly.
- Retains proper Runtime/Editor asmdefs, UdonSharp assembly registration, VerdantRoleAuthority, clock/version repair, and smoother supporter scrolling.

After updating through VCC:
1. Reopen Unity and let compilation finish.
2. Check **Tools > Verdant Board > Diagnostics > Package Status**.
3. Then run **Tools > Verdant Board > V15.4.6 > Apply Supporters + Clock + Version Fix**.
