# Verdant World System 15.4.9

V15.4.9 refines the visible version UI without changing the working Verdant layout.

## Version UI

- Replaces the tiny floating Main Board version text with a compact Verdant status card.
- Copies the nearby PLAYERS card's background sprite, panel colour/material and typography where available.
- Uses the same two-line visual language: **VERSION** above the build number.
- Keeps a green Verdant accent strip.
- Preserves the old version label's position so the layout does not jump.
- Updates the existing iPad/tablet version text to the same numeric build: **15.4.9**.
- If the iPad version label is missing, adds a subtle fallback inside the existing StatusBar rather than adding another panel.

V15.4.9 retains the 15.4.8 supporter ownership fix, clock controller, VerdantRoleAuthority and the repaired VPM assembly structure.

After updating through VCC:
Tools > Verdant Board > V15.4.9 > Apply Supporters + Clock + Version Fix
