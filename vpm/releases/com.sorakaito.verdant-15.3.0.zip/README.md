# Verdant World System

Verdant is a VRChat world framework maintained by SoraKaito0.

This VPM package intentionally contains Verdant-managed scripts and editor tooling, not your whole world scene. Scene-specific objects, manually placed props, cats, supporter items, lighting and world configuration remain in your project so VCC updates do not replace their transforms.

## Included

- Verdant Update Manager
- V15 cumulative migration tools
- YouTube/media/UI repair tools
- Supporter/staff role authority
- Optional VRCLinking bridge installer

## Optional integrations

Verdant can work with VRCLinking, AudioLink and ProTV when those packages are installed separately. They are not hard dependencies, so installing Verdant does not force extra packages into every world.

## Updating

Use VRChat Creator Companion > Manage Project > Verdant World System.

Repository:
https://sorakaito0.github.io/verdant-media/index.json
