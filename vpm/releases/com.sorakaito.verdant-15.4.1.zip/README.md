# Verdant World System 15.4.1

Hotfix for projects migrated from older Verdant .unitypackage builds.

V15.4.1 changes legacy cleanup from GUID-dependent matching to exact path-based matching. This lets VCC remove old Verdant-managed script copies under Assets/VerdantBoard when installing/updating the VPM package, preventing duplicate class definitions.

Only known Verdant-managed legacy script files are targeted. Scene objects, manually positioned cats, supporter props, lighting and world-specific assets are not removed.

After VCC updates Verdant, reopen Unity and let it compile. Then run:

Tools > Verdant Board > V15.4 > Apply Supporter Scroll + Clock Sync Fix
