# Verdant World System 15.4.8

V15.4.8 fixes the remaining Supporters-page ownership conflict and the missing Main Board version label.

## Supporters page

The repair now:
- identifies one active Supporters/member/name-list ScrollRect as the primary list
- removes the old VerdantVpmScrollKeeper component from Supporters list ScrollRects
- identifies duplicate legacy supporter UI branches under the same Supporters page
- disables those legacy branches in the scene
- installs VerdantSupporterOwnership1548, which keeps those legacy branches disabled at runtime
- preserves the primary list position without the previous every-frame scroll fight

## Version labels

The repair now:
- updates existing Verdant version/build text to V15.4.8
- detects the actual Main Board from VerdantBoard when available
- finds the active Canvas inside that board
- creates the missing version label on that Canvas, not just the board root
- sizes the label from existing Main Board typography and puts it last in the Canvas hierarchy

After updating through VCC:
1. Reopen Unity and let compilation finish.
2. Check **Tools > Verdant Board > Diagnostics > Package Status**.
3. Run **Tools > Verdant Board > V15.4.8 > Apply Supporters + Clock + Version Fix**.
