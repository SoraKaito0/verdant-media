# Verdant World System 15.4.0

Managed through the Verdant VCC/VPM repository.

## V15.4 fixes

- Supporter/member recognition ScrollRects keep their position across runtime list/layout refreshes.
- Main Board and iPad clock displays use one shared local clock source.
- 12/24-hour state is shared between linked Verdant clock controls and displays.
- Clock output uses the local machine time instead of a hard-coded UTC offset, avoiding DST/manual-offset drift.

After updating in VCC, open Unity and run:

Tools > Verdant Board > V15.4 > Apply Supporter Scroll + Clock Sync Fix

The installer makes a scene backup first.
